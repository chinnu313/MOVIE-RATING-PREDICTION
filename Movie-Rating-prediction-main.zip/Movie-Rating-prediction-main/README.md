# Movie-Rating-prediction
"I developed a machine learning model to predict movie ratings based on various features like genre, cast, and director. By leveraging algorithms such as Random Forest and XGBoost, I was able to achieve strong prediction accuracy. This project enhanced my skills in data preprocessing, feature engineering, and model evaluation."
